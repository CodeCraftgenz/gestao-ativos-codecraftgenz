﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace OverlayCraft
{
    public partial class frm_Sobre : Form
    {
        public frm_Sobre()
        {
            InitializeComponent();
        }

        private void frm_Sobre_Load(object sender, EventArgs e)
        {
            // Configurações visuais básicas
            this.BackColor = Color.FromArgb(30, 30, 30);
            this.Opacity = 0.97;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Text = "Sobre o OverlayCraft";

            // Ajuste opcional de cor no LinkLabel
            lklb_Site.LinkColor = Color.MediumPurple;
            lklb_Site.VisitedLinkColor = Color.DeepPink;

            
        }

        private void lklb_Site_Click(object sender, EventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = "https://codecraftgenz.com.br/",
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Não foi possível abrir o site:\n" + ex.Message,
                    "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}